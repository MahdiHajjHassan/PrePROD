import { createDb } from "../src/backend/database/db";
import { loadConfig } from "../src/backend/config/env";
import { seedDatabase } from "../src/backend/database/seed";
import { hashPassword } from "../src/backend/modules/auth/password";
const supplied = process.argv[process.argv.indexOf("--project") + 1],
  project = process.env.TICTACTOE_E2E_PROJECT;
const origin = new URL(process.env.APP_ORIGIN ?? "https://invalid");
if (
  !project ||
  !/^tictactoe-e2e-[a-z0-9-]+$/.test(project) ||
  supplied !== project ||
  origin.hostname !== "localhost" ||
  Number(origin.port) < 1024 ||
  process.env.DATABASE_URL !== "file:/data/tictactoe.db"
)
  throw new Error("Refusing reset outside the explicitly isolated test container");
const config = loadConfig(process.env),
  db = await createDb(config.databaseUrl);
try {
  await db.$transaction([
    db.emailChallenge.deleteMany(),
    db.gameMove.deleteMany(),
    db.game.deleteMany(),
    db.tournamentMatch.deleteMany(),
    db.tournamentEntry.deleteMany(),
    db.tournament.deleteMany(),
    db.session.deleteMany(),
    db.rateLimitBucket.deleteMany(),
    db.user.deleteMany(),
  ]);
  await seedDatabase(db, config);
  await db.user.updateMany({ data: { emailVerifiedAt: new Date() } });
  const passwordHash = await hashPassword(config.adminPassword);
  await db.user.createMany({
    data: [
      {
        email: "member-a@example.test",
        displayName: "Member A",
        passwordHash,
        emailVerifiedAt: new Date(),
      },
      {
        email: "member-b@example.test",
        displayName: "Member B",
        passwordHash,
        emailVerifiedAt: new Date(),
      },
      {
        email: "member-c@example.test",
        displayName: "Member C",
        passwordHash,
        emailVerifiedAt: new Date(),
      },
      {
        email: "member-d@example.test",
        displayName: "Member D",
        passwordHash,
        emailVerifiedAt: new Date(),
      },
    ],
  });
  console.log("Reset only the guarded isolated game database with five demonstration accounts.");
} finally {
  await db.$disconnect();
}
