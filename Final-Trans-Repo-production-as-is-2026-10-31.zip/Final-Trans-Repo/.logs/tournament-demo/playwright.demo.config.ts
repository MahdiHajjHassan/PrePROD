import { defineConfig } from '@playwright/test';
import { resolve } from 'node:path';
import base from '../../playwright.config';
const root = resolve(import.meta.dirname, '../..');
export default defineConfig({
  ...base,
  testDir: resolve(root, 'tests/browser'),
  globalSetup: resolve(root, 'tests/helpers/e2e-setup.ts'),
  outputDir: resolve(root, '.logs/tournament-demo/results'),
  reporter: [['list'], ['html', { open: 'never', outputFolder: resolve(root, '.logs/tournament-demo/report') }]],
  use: { ...base.use, headless: false, screenshot: 'on', video: 'on', trace: 'on' },
  projects: base.projects?.filter(p => p.name === 'chrome').map(p => ({
    ...p, use: { ...p.use, launchOptions: { ...p.use?.launchOptions, slowMo: 180 } }
  }))
});
